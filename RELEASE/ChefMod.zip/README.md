## ChefMod
CHEF is a robot cook who is capable of serving generous helpings to even the largest crowds. Supports StandaloneAncientScepter!
[![](https://i.imgur.com/SFP5RIj.jpeg)]()

[![](https://i.imgur.com/lyhIDFe.jpeg)]()
[![](https://i.imgur.com/eqp6HDQ.png)]()

If you have any feedback/suggestions, open an issue on the Github page, or join our discord at https://discord.gg/pKE3QCEsxG 

## Installation
Drop the Gnome-ChefMod folder into \BepInEx\plugins\
All players need the mod.

## Known Issues
- nonw

## To Do
- Add config option to keep CHEF bossfight after completing the unlock.
- Character select animation.
- More alt skills.
- Balancing. Feedback is greatly appreciated!

## Credits
Huge thanks to 

- Lucid Inceptor for being my muse (made the models)
- Papa Zach for being my longest supporter (made icons)
- Timesweeper for being my rock (helped me implement animation, and various tweaks)
- Moffein for being there when I needed him most (helped me patch for anniversary update and did networking and the 2.0 update)
- rob for being the father I always dreamd of (gave advice)
- Swuff for taking care of my needs (pleasured me, and made animations)
- SOM for the CSS anim.

And as always I give my undying love to iDeathHD

oh and thank you enigma for letting me use your prefab builder it is very cool
the mod icon was made by Destructor check out his youtube Destructor1089 for risk of rain 2 sfm

Thanks to Gnome for being the big bang in an otherwise cold and empty universe. 
Whether or not you come back to work on him, we'll be here for ya.

## Localization Credits

Chinese - JunJun_w

Russian - Адский Шкед, marklecard

Ukrainian - Damglador

Spanish - Juhnter

Japanese - punch